let humanScore = 0;
let computerScore = 0;
let currentRoundNumber = 1;

// Write your code below:
const generateTarget = ()=> {
return Math.floor(Math.random() * 9);
};
const compareGuesses = (humanGuess, computerGuess, targetNumber)=> {
/*  if (humanGuess < 0 || humanGuess > 9){
    alert("Your guess number is out of range.")
  }*/
  
  if (Math.abs(humanGuess-targetNumber) < Math.abs(computerGuess - targetNumber)){
    console.log("You win!!!")
    return true
  }
  else if (Math.abs(computerGuess-targetNumber) < Math.abs(humanGuess - targetNumber)){
    console.log("Computer wins!!!")
    return false
  }
  else {
    console.log("You win!!!")
    return true
  }
  };
const updateScore = winnerScore  => {
if (winnerScore = 'human'){
  humanScore +=1;
}
else if (winnerScore = 'computer') {
  computerScore +=1;
}
else {
  return humanScore +=1;
}
};

const  advanceRound = () => {
  currentRoundNumber +=1;
}



/*
getAbsoluteDistance = (humanGuessDistance , computerGuessDistance) => {
    return humanGuessDistance = Math.abs(humanGuess-targetNumber)
    return computerGuessDistance = Math.abs(computerGuess - targetNumber)
}*/
